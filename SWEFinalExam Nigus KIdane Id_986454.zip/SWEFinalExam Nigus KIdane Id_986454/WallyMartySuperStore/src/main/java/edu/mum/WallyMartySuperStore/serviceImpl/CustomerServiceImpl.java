package edu.mum.WallyMartySuperStore.serviceImpl;

import edu.mum.WallyMartySuperStore.model.Customer;
import edu.mum.WallyMartySuperStore.repository.CustomerRepository;
import edu.mum.WallyMartySuperStore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    CustomerRepository customerRepository;

    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public List<Customer> getAllCustomers() {
        return (List<Customer>) customerRepository.findAll();
    }
}
