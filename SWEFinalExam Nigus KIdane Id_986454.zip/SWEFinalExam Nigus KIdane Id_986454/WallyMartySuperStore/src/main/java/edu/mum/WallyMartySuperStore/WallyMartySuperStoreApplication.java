package edu.mum.WallyMartySuperStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WallyMartySuperStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(WallyMartySuperStoreApplication.class, args);
	}
}
