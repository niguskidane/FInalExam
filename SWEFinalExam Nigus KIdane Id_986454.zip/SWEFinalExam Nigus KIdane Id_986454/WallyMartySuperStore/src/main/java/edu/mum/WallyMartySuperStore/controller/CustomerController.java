package edu.mum.WallyMartySuperStore.controller;

import com.sun.org.apache.xpath.internal.operations.Mod;
import edu.mum.WallyMartySuperStore.model.Customer;
import edu.mum.WallyMartySuperStore.repository.CustomerRepository;
import edu.mum.WallyMartySuperStore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import javax.validation.Valid;

@Controller
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @GetMapping(value = "/customers")
    public String getAllCustomers(Model model){
        model.addAttribute("customers", customerService.getAllCustomers());
        return "customer/list";
    }

    @GetMapping(value = "/customer")
    public String getCustomerForm(@ModelAttribute("customer")Customer customer, Model model){
        return "customer/new";
    }

    @PostMapping(value = "/add")
    public String addNewCustomer(@Valid @ModelAttribute("customer") Customer customer, BindingResult result, Model model){

        if(result.hasErrors()){
            model.addAttribute("errors", result.getAllErrors());
            return "customer/new";
        }
        customer=customerService.saveCustomer(customer);
        return "redirect:/customers";
    }




}
