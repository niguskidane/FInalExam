package edu.mum.WallyMartySuperStore.controller;

import edu.mum.WallyMartySuperStore.model.Customer;
import edu.mum.WallyMartySuperStore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.sql.DatabaseMetaData;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
public class PrimeCustomerController {

    @Autowired
    CustomerService customerService;


    /*@ModelAttribute
    public static List<Customer> getPrimeCustomers(List<Customer> input){
        List<Customer> customerAbove40=new ArrayList<>();
       //LocalDate date=LocalDate.of(1978, 1, 1);
        Date date=null;
        date.setYear(1978);
        date.setMonth(01);
        date.setDate(01);

        for(Customer c: input){
            if(c.getDateOfBirth().compareTo(date)>1){
                customerAbove40.add(c);
            }
        }
        return customerAbove40;
    }*/

    @GetMapping(value = "/primeCustomers")
    public String getAllPrimeCustomers(Model model){
        //List<Customer> input=customerService.getAllCustomers();
       model.addAttribute("customers", customerService.getAllCustomers());
       // model.addAttribute("customers", getPrimeCustomers(input));
        return "primeCustomer/list";
    }


}
