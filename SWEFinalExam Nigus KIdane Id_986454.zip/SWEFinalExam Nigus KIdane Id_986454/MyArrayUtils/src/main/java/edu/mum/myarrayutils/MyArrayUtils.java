package edu.mum.myarrayutils;

public class MyArrayUtils {

    public boolean hasMultipleMaximum(int[] a_in) {
        if (a_in == null || a_in.length == 1) {
            return false;
        }
        int maxValue=getMax(a_in);
        int count=0;
        boolean hasMoreMax = false;
        for (int i = 0; i < a_in.length; i++) {
            if (a_in[i]==maxValue) {
                count++;
            }
            if(count>1){
                hasMoreMax=true;
            }
        }
        return hasMoreMax;
    }

    public static int getMax(int[] a_in){
        if(a_in==null || a_in.length==1){
            return 0;
        }
        int max = 0;
        for (int i = 0; i < a_in.length; i++) {
            if (a_in[i] > max) {
                max = a_in[i];
            }
        }
        return max;
    }

   /* public static void main(String[] args){
        MyArrayUtils arrayUtils=new MyArrayUtils();
        System.out.println(arrayUtils.hasMultipleMaximum(new int[]{-6, 2, 5, 6, -6, 5, 6}));
        System.out.println(arrayUtils.hasMultipleMaximum(new int[]{-6, 3,7, 6}));
        System.out.println(arrayUtils.hasMultipleMaximum(new int[]{1,1,1}));
        System.out.println(arrayUtils.hasMultipleMaximum(null));
    }*/
}
